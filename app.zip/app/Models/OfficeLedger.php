<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OfficeLedger extends Model
{
      protected $guarded=[''];
}
